from flask import Flask, request, jsonify, render_template, redirect, session
import hashlib, os, psycopg2, datetime
from functools import wraps

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.environ.get('JWT_SECRET', 'secret')

import os

# БД
def get_db():
    return psycopg2.connect(
        host=os.environ.get('POSTGRES_HOST', 'postgres-db'),
        user=os.environ.get('POSTGRES_USER', 'app_user'),
        password=os.environ.get('POSTGRES_PASSWORD', 'SecurePass123'),
        database=os.environ.get('POSTGRES_DB', 'userdb')
    )

@app.route('/profile/<username>')
@login_required
def profile():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('select username, email fromusers where username=%s',(username,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    if user:
        return jsonify({
            'username': user[0],
            'email': user[1],
            'role':'admin' if user[0] == 'admin' else 'user'
        })
    return jsonify({'error':'user not found'}),404

@app.route('/health')
def health():
    return jsonify({'status': 'ok'})

@app.route('/debug')
def debug():
    return {
        'AUTH_TITLE': os.environ.get('AUTH_TITLE'),
        'AUTH_WELCOME': os.environ.get('AUTH_WELCOME'),
        'PROFILE_SERVICE_URL': os.environ.get('PROFILE_SERVICE_URL'),
        'JWT_SECRET': os.environ.get('JWT_SECRET')[:10] + '...',
        'API_KEY': os.environ.get('API_KEY')[:10] + '...',
    }

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)