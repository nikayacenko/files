from flask import Flask, request, jsonify, render_template, redirect, session
import hashlib, os, psycopg2, datetime
from functools import wraps

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.environ.get('JWT_SECRET', 'secret')

import os


# уведомления
notifications = [
    {'id': 1, 'title': 'Гран-при Монако', 'message': 'Следующая гонка: 26 мая 2024, 15:00', 'date': '2024-05-20'},
    {'id': 2, 'title': 'Обновление системы', 'message': 'Доступна новая версия F1 Management', 'date': '2024-05-19'},
]

@app.route('/notifications')
@login_required
def notifications_page():
    return jsonify(notifications)

@app.route('/admin')
@login_required
@admin_required
def admin_panel():
    return render_template('admin.html', notifications=notifications)

@app.route('/notify', methods=['POST'])
def send_notification():
    data = request.json
    new_id = len(notifications)+1
    notifications.append({
        'id':new_id,
        'title':data.get('title'),
        'message':data.get('message'),
        'date':datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    })
    return jsonify({'status':'sent','id':new_id})


@app.route('/health')
def health():
    return jsonify({'status': 'ok'})

@app.route('/debug')
def debug():
    return {
        'AUTH_TITLE': os.environ.get('AUTH_TITLE'),
        'AUTH_WELCOME': os.environ.get('AUTH_WELCOME'),
        'PROFILE_SERVICE_URL': os.environ.get('PROFILE_SERVICE_URL'),
        'JWT_SECRET': os.environ.get('JWT_SECRET')[:10] + '...',
        'API_KEY': os.environ.get('API_KEY')[:10] + '...',
    }

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003)